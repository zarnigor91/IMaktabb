package com.example.imaktab.home_work.confirms

interface IConfirmsPeresenter {
   fun getConfirms(confirmRequest: ConfirmRequest)
}