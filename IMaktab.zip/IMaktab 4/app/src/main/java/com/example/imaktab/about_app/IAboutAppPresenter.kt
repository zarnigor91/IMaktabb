package com.example.imaktab.about_app

interface IAboutAppPresenter{
    fun getAboutApp()
    fun clearRequest()
}