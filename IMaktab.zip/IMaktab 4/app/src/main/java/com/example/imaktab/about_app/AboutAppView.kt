package com.example.imaktab.about_app

import com.example.imaktab.BaseView

interface AboutAppView :BaseView{
     fun aboutResponce(aboutModel: AboutModel)
}