package com.example.imaktab.classScheduleFragment

interface IClassSchedulePresenter {
    fun geteWekSchedule(date: String)
    fun getPupilListByParentId()
    fun clearRequest()
}