package com.example.imaktab.continuation_general.general

import android.util.Log
import com.example.imaktab.App
import com.example.imaktab.IMAKTAB
import com.example.imaktab.network.ApiClient
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class GeneralPresenterImple(val view: GeneralView):IGeneralPresenter{
    override fun getContinuationWeek( date:String) {
            var pupilId = App.getCurrentPupilId()
            ApiClient.apiClinet.getWeekContinuation(pupilId!!.toLong(),date)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    Log.e(IMAKTAB, "SUCCESS week: "+date)

                    view.getWeekResponce(it)
                },{
                    Log.e(IMAKTAB, "ERROR week: "+it.message)
                })
        }


}