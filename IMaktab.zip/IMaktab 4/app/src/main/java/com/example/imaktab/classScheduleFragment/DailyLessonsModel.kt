package com.example.imaktab.classScheduleFragment

import org.threeten.bp.LocalDate

data class DailyLessonsModel(
    val dayName:String,
    var date:LocalDate,
    var lessons:List<LessonModel>
)