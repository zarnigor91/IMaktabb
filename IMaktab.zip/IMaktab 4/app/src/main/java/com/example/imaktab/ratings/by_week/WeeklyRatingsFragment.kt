package com.example.imaktab.ratings.by_week

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.imaktab.BaseFragment
import com.example.imaktab.R
import com.example.imaktab.home_work.passed.WeekMarkModel
import com.example.imaktab.home_work.passed.WeekPArentMarkAdapter
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog
import kotlinx.android.synthetic.main.weekly_ratings_fragment.*
import org.threeten.bp.DayOfWeek
import org.threeten.bp.LocalDate
import java.util.*
import kotlin.collections.ArrayList


class WeeklyRatingsFragment : BaseFragment(R.layout.weekly_ratings_fragment), IWeekMarkView,
    DatePickerDialog.OnDateSetListener {
    private var adapterWeek: WeekPArentMarkAdapter? = null
    private val presenter: IWeekMarkPresenter = WeekMarkPresenterImple(this)
    var emptyList = ArrayList<DailyWeekMarkModel>()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        init()
        tv_date_week_rating.setOnClickListener {
            showDatePicker()
        }
    }

    override fun onStart() {
        super.onStart()
        presenter.getWeekMark("${LocalDate.now().year}-${String.format("%02d", LocalDate.now().month.value)}-${String.format("%02d", LocalDate.now().with(DayOfWeek.MONDAY).dayOfMonth)}")
    }

    private fun init() {
        showProgressDialog()
        adapterWeek = WeekPArentMarkAdapter(emptyList, context!!)
        rv_week_mark.layoutManager = LinearLayoutManager(context)
        rv_week_mark.adapter = adapterWeek
    }

    private fun convertWeeklyToDaily(weekMarkModel: WeekMarkModel): List<DailyWeekMarkModel> {
        var list = mutableListOf<DailyWeekMarkModel>()
        val c = Calendar.getInstance()
//ensure the method works within current month
        //ensure the method works within current month
        c[Calendar.DAY_OF_WEEK] = Calendar.MONDAY
        val currentDayOfMonth = c[Calendar.DAY_OF_MONTH]
        val t = c.get(Calendar.DAY_OF_MONTH)
        Log.d("pas", "dateC" + c.firstDayOfWeek.toString())
        list.add(DailyWeekMarkModel(getString(R.string.monday), LocalDate.now().with(DayOfWeek.MONDAY), weekMarkModel.monday))
        list.add(DailyWeekMarkModel(getString(R.string.tuesday), LocalDate.now().with(DayOfWeek.TUESDAY), weekMarkModel.tuesday))
        list.add(DailyWeekMarkModel(getString(R.string.wednesday), LocalDate.now().with(DayOfWeek.WEDNESDAY), weekMarkModel.wednesday))
        list.add(DailyWeekMarkModel(getString(R.string.thursday), LocalDate.now().with(DayOfWeek.THURSDAY), weekMarkModel.thursday))
        list.add(DailyWeekMarkModel(getString(R.string.friday), LocalDate.now().with(DayOfWeek.FRIDAY), weekMarkModel.friday))
        list.add(DailyWeekMarkModel(getString(R.string.saturday), LocalDate.now().with(DayOfWeek.SATURDAY), weekMarkModel.saturday))
        return list
    }

    override fun getWeekvalue(weekMarkModel: WeekMarkModel) {
        emptyList = convertWeeklyToDaily(weekMarkModel) as ArrayList<DailyWeekMarkModel>
        hideProgressDialog()
        Log.d("pas", "weekky" + emptyList)
        adapterWeek?.updateList(emptyList)


    }

    override fun onDestroy() {
        super.onDestroy()
        presenter.clearRequest()
    }

    private fun showDatePicker() {
        var calendar = Calendar.getInstance()

        val dpd =
            DatePickerDialog.newInstance(
                this,
                calendar[Calendar.YEAR],
                calendar[Calendar.MONTH],
                calendar[Calendar.DAY_OF_MONTH]
            )
        dpd.show(activity!!.fragmentManager, "DatePickerDialog")
        val g1 = GregorianCalendar()
        g1.add(Calendar.DATE, 1)
        g1.add(Calendar.DATE, 3)
        g1.add(Calendar.DATE, 4)
        g1.add(Calendar.DATE, 5)
        g1.add(Calendar.DATE, 6)
        g1.add(Calendar.DATE, 7)
        val gc = GregorianCalendar()
        gc.add(Calendar.DAY_OF_MONTH, 30)
        val dayslist: MutableList<Calendar> = LinkedList()
        val daysArray: Array<Calendar?>
        val cAux = Calendar.getInstance()
        while (cAux.timeInMillis <= gc.timeInMillis) {
            if (cAux[Calendar.DAY_OF_WEEK] !== 1 && cAux[Calendar.DAY_OF_WEEK] !== 3 && cAux[Calendar.DAY_OF_WEEK] !== 4 && cAux[Calendar.DAY_OF_WEEK] !== 5
                && cAux[Calendar.DAY_OF_WEEK] !== 6 && cAux[Calendar.DAY_OF_WEEK] !== 7
            ) {
                val c = Calendar.getInstance()
                c.timeInMillis = cAux.timeInMillis
                dayslist.add(c)
            }
            cAux.timeInMillis = cAux.timeInMillis + 24 * 60 * 60 * 1000
        }
        daysArray = arrayOfNulls(dayslist.size)
        for (i in daysArray.indices) {
            daysArray[i] = dayslist[i]
        }
        dpd.setSelectableDays(daysArray)
    }

    @SuppressLint("SetTextI18n")
    override fun onDateSet(view: DatePickerDialog?, year: Int, monthOfYear: Int, dayOfMonth: Int) {
        val da = LocalDate.of(year, monthOfYear+1, dayOfMonth)
        (emptyList[0].lessons as ArrayList).clear()
        emptyList[0].date = da
        emptyList[1].date = da.plusDays(1)
        emptyList[2].date = da.plusDays(2)
        emptyList[3].date = da.plusDays(3)
        emptyList[4].date = da.plusDays(4)
        emptyList[5].date = da.plusDays(5)
        val date = "$year-${String.format("%02d", monthOfYear)}-${String.format("%02d", dayOfMonth)}"
        tv_date_week_rating.text = "${String.format("%02d", dayOfMonth)}-${String.format("%02d", monthOfYear+1)}-$year"
        presenter.getWeekMark(date)
        adapterWeek?.updateList(emptyList)
        adapterWeek?.notifyDataSetChanged()
    }

}