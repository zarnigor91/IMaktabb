package com.example.imaktab.dashboard.continuation

interface IContinuationPresenter {
    fun getScheduleTodayByPupilId()
    fun getPupilListByParentId()
    fun getTotal()
    fun getDashboardPupils()

}