package com.example.imaktab.ratings.by_science

import android.annotation.SuppressLint
import android.util.Log
import com.example.imaktab.App
import com.example.imaktab.IMAKTAB
import com.example.imaktab.network.ApiClient
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class ScienMarkPresenterImple(val view: IScienMarkView):IScienMarkPresenter{
    override fun getScienMark(subject: Int, month: Int) {
        var pupilId = App.getCurrentPupilId()
        ApiClient.apiClinet.getMarkByMonth(pupilId!!.toLong().toInt(), subject,month)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({
                view.getScienMarksResponce(it)
                Log.d("dsfs","succesScin"+it)
            },{
                Log.e(IMAKTAB, "ERROR week: "+it.message)
            })
    }

    override fun getMarkBySubjectAndMonth(subject: Int, month: Int) {
        var pupilId = App.getCurrentPupilId()
        ApiClient.apiClinet.getMarkByMonth(pupilId!!.toLong().toInt(), subject,month)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({
                view.onGetAttendanceBySubjectAndMonth(it)
                Log.d(IMAKTAB, "SUCCESS on get AttendanceBySubjectAndMonth: $it")
            },{
                Log.e(IMAKTAB, "ERROR on get AttendanceBySubjectAndMonth: "+it.message)
            })
    }
    @SuppressLint("CheckResult")
    override fun getSubjects() {
        ApiClient.apiClinet.getSubjects()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({
                view.onGetSubjects(it)
                Log.d(IMAKTAB, "SUCCESS on get subjects: $it")
            },{
                Log.e(IMAKTAB, "ERROR on get subjects: " + it.message)
            })
    }

}