package com.example.imaktab.continuation_general

interface IGeneralConPresenter {
    fun clearRequest()
    fun getPupilListByParentId()

}