package com.example.imaktab.classScheduleFragment

import android.util.Log
import com.example.imaktab.App
import com.example.imaktab.IMAKTAB
import com.example.imaktab.network.ApiClient
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers

class ChildSchedulePresenterImple(val view: ClassScheduleView):IClassSchedulePresenter{
    private var compositeDisposable = CompositeDisposable()
    override fun geteWekSchedule(date: String) {
        val pupilId = App.getCurrentPupilId()
        val  disposable = ApiClient.apiClinet.getweekScheduleByPupilId(pupilId!!.toLong())
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({
                Log.e(IMAKTAB, "SUCCESS on get class schedular Today: $it")
                if (it.monday[0].date == date)
                view.getResponsValue(it)
            },{
                Log.e(IMAKTAB, "ERROR on get class schedular Today: "+it.message)
            })
        compositeDisposable.add(disposable)
    }

    override fun getPupilListByParentId() {
        val disposable = ApiClient.apiClinet.getPupilListByParentId(view.parentId())
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({
                Log.e(IMAKTAB, "SUCCESS on get pupilList by parentid: "+it.toString())
                view.onGetPupilSuccess(it)
            },{
                Log.e(IMAKTAB, "ERROR on get pupilList by parentid"+it.message)
            })
        compositeDisposable.add(disposable)
    }

    override fun clearRequest() {
        compositeDisposable.dispose()
    }

}