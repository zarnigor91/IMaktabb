package com.example.imaktab.dashboard

data class Total(
    val total:Float
)