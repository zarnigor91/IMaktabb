package com.example.imaktab.ratings.by_science

interface IScienMarkPresenter {
    fun getScienMark(subject:Int,month:Int)
    fun getMarkBySubjectAndMonth(subject:Int, month:Int)
    fun getSubjects(){}
}