package com.example.imaktab.continuation_general.general

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.imaktab.BaseFragment
import com.example.imaktab.R
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog
import kotlinx.android.synthetic.main.general_fgragment.*
import kotlinx.android.synthetic.main.weekly_ratings_fragment.*
import org.threeten.bp.DayOfWeek
import org.threeten.bp.LocalDate
import java.lang.String.format
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList


@Suppress("DEPRECATED_IDENTITY_EQUALS")
class GeneralFragment : BaseFragment(R.layout.general_fgragment),
    DatePickerDialog.OnDateSetListener, GeneralView {
    private val presenter: IGeneralPresenter = GeneralPresenterImple(this)
    private var adapter: WeekContinuationAdapter? = null
    private var dateGeneral: String? = null
    private val list = ArrayList<DailyContinuationModel>()
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        init()
        tv_conti_data.setOnClickListener {
            showDatePicker()
        }
    }

    override fun onStart() {
        super.onStart()
        val startDateString = LocalDate.now().with(DayOfWeek.MONDAY).toString()
        val sdf = SimpleDateFormat("dd-MM-yyyy")
        val sdf2 = SimpleDateFormat("yyyy-MM-dd")
        println(sdf2.format(sdf.parse(startDateString)))
        presenter.getContinuationWeek(sdf.format(sdf2.parse(startDateString)))
        val format = SimpleDateFormat("dd-MM-YYYY")
    }

    private fun init() {
        showProgressDialog()
        adapter = WeekContinuationAdapter(listOf(), context!!)
        rv_continuation.layoutManager = LinearLayoutManager(this@GeneralFragment.context)
        rv_continuation.adapter = adapter
    }

    private fun convertWeeklyToDaily(weeklyContinuationModel: WeeklyContinuationModel): List<DailyContinuationModel> {
        val list = mutableListOf<DailyContinuationModel>()

        weeklyContinuationModel.apply {
            list.add(DailyContinuationModel(getString(R.string.monday), LocalDate.now().with(DayOfWeek.MONDAY), monday))
            list.add(DailyContinuationModel(getString(R.string.tuesday), LocalDate.now().with(DayOfWeek.TUESDAY), tuesday))
            list.add(DailyContinuationModel(getString(R.string.wednesday), LocalDate.now().with(DayOfWeek.WEDNESDAY), wednesday))
            list.add(DailyContinuationModel(getString(R.string.thursday), LocalDate.now().with(DayOfWeek.THURSDAY), thursday))
            list.add(DailyContinuationModel(getString(R.string.friday), LocalDate.now().with(DayOfWeek.FRIDAY), friday))
            list.add(DailyContinuationModel(getString(R.string.saturday), LocalDate.now().with(DayOfWeek.SATURDAY), saturday))
        }
        return list
    }

    override fun getWeekResponce(weeklyContinuationModel: WeeklyContinuationModel) {
        list.addAll(convertWeeklyToDaily(weeklyContinuationModel))
        hideProgressDialog()
        adapter?.updateList(list)
    }

    override fun getDate(): String {
        dateGeneral = tv_conti_data.text.toString()
        return dateGeneral.toString()
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()

        val dpd =
            DatePickerDialog.newInstance(
                this,
                calendar[Calendar.YEAR],
                calendar[Calendar.MONTH],
                calendar[Calendar.DAY_OF_MONTH]
            )
        dpd.show(activity!!.fragmentManager, "DatePickerDialog")
        val g1 = GregorianCalendar()
        g1.add(Calendar.DATE, 1)
        g1.add(Calendar.DATE, 3)
        g1.add(Calendar.DATE, 4)
        g1.add(Calendar.DATE, 5)
        g1.add(Calendar.DATE, 6)
        g1.add(Calendar.DATE, 7)
        val gc = GregorianCalendar()
        gc.add(Calendar.DAY_OF_MONTH, 30)
        val list: MutableList<Calendar> = LinkedList()
        val daysArray: Array<Calendar?>
        val cAux = Calendar.getInstance()
        while (cAux.timeInMillis <= gc.timeInMillis) {
            if (cAux[Calendar.DAY_OF_WEEK] !== 1 && cAux[Calendar.DAY_OF_WEEK] !== 3 && cAux[Calendar.DAY_OF_WEEK] !== 4 && cAux[Calendar.DAY_OF_WEEK] !== 5
                && cAux[Calendar.DAY_OF_WEEK] !== 6 && cAux[Calendar.DAY_OF_WEEK] !== 7
            ) {
                val c = Calendar.getInstance()
                c.timeInMillis = cAux.timeInMillis
                list.add(c)
            }
            cAux.timeInMillis = cAux.timeInMillis + 24 * 60 * 60 * 1000
        }
        daysArray = arrayOfNulls(list.size)
        for (i in daysArray.indices) {
            daysArray[i] = list[i]
        }
        dpd.selectableDays = daysArray
    }

    override fun onDateSet(view: DatePickerDialog?, year: Int, monthOfYear: Int, dayOfMonth: Int) {
        val da = LocalDate.of(year, monthOfYear+1, dayOfMonth)
        (list[0].lessons as ArrayList).clear()
        list[0].date = da
        list[1].date = da.plusDays(1)
        list[2].date = da.plusDays(2)
        list[3].date = da.plusDays(3)
        list[4].date = da.plusDays(4)
        list[5].date = da.plusDays(5)
        val date = "$year-${String.format("%02d", monthOfYear)}-${String.format("%02d", dayOfMonth)}"
        tv_conti_data.text = "${String.format("%02d", dayOfMonth)}-${String.format("%02d", monthOfYear+1)}-$year"
        presenter.getContinuationWeek(date)
        adapter?.updateList(list)
    }
}