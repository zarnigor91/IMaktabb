package com.example.imaktab.login

data class LoginResponce(
    val key:String
)