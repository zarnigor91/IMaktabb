package com.example.imaktab.login

data class Parent(
    val id:Long
)