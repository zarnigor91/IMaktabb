package com.example.imaktab.home_work.passed

interface IPassedPresenter {
      fun getPassed()
    fun clearRequest()
}