package com.example.imaktab.home_work.tomorrow_homeWork

data class Subject(
    val  subject:String
)