package com.example.imaktab.verification

data class CheckSmsRequestModel(

    val code:String

)