package com.example.imaktab

public val PARENT_ID_KEY = "PARENT_ID"
public val TOKEN_KEY = "TOKEN"
public val IMAKTAB = "IMAKTAB"
public val HAFTA = listOf<String>(
    "DUSHANBA",
    "SESHANBA",
    "CHORSHANBA",
    "PAYSHANBA",
    "JUMA",
    "SHANBA",
    "YAKSHANBA"
)
val PREFERENCE = "my_preference"
val PREF_USER = "pref_user"
val PREF_PASS= "pref_pass"