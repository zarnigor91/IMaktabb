package com.example.imaktab.login
data class LoginRequest(
    val username:String,
    val password:String
)