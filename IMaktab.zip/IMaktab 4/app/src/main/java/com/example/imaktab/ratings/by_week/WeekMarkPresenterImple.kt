package com.example.imaktab.ratings.by_week

import android.util.Log
import com.example.imaktab.App
import com.example.imaktab.IMAKTAB
import com.example.imaktab.network.ApiClient
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers

class WeekMarkPresenterImple(val view: IWeekMarkView):IWeekMarkPresenter{
    private var compositeDisposable = CompositeDisposable()
    override fun getWeekMark(date:String) {
        val pupilId = App.getCurrentPupilId()
        val disposable= ApiClient.apiClinet.getMarkByWeek(pupilId!!.toInt(),date)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({
                if (date == it.monday[0].date)
                    view.getWeekvalue(it)
                Log.e(IMAKTAB, "week: "+it.toString())
                Log.d("pas","passed week"+it)
            },{
                Log.e(IMAKTAB, "ERROR on get work: "+it.message)
            })
        compositeDisposable.add(disposable)

    }

    override fun clearRequest() {
        compositeDisposable.dispose()
    }

}