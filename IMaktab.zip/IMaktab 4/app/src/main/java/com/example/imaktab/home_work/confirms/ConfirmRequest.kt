package com.example.imaktab.home_work.confirms

class ConfirmRequest(
    val pupil:Int,
    val parent:Int,
    val homework:Int
)


