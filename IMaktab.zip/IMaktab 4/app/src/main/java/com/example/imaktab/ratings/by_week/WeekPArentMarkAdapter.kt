package com.example.imaktab.home_work.passed

import android.content.Context
import android.text.format.DateFormat
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.imaktab.R
import com.example.imaktab.ratings.by_week.DailyWeekMarkModel
import com.example.imaktab.ratings.by_week.WeekChildMarkAdapter
import kotlinx.android.extensions.LayoutContainer
import kotlinx.android.synthetic.main.item_day_science.view.*
import kotlinx.android.synthetic.main.item_week_mark_parent.view.*
import org.threeten.bp.DayOfWeek
import org.threeten.bp.LocalDate
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList


class WeekPArentMarkAdapter(val list: List<DailyWeekMarkModel>, val context: Context) :
    RecyclerView.Adapter<WeekPArentMarkAdapter.ViewHolder>() {
    private val viewPool = RecyclerView.RecycledViewPool()
    private var mylist = mutableListOf<DailyWeekMarkModel>()
    private val monthList: Array<String> = arrayOf(
        context.getString(R.string.januar),
        context.getString(R.string.februare),
        context.getString(R.string.march),
        context.getString(R.string.april),
        context.getString(R.string.may),
        context.getString(R.string.june),
        context.getString(R.string.july),
        context.getString(R.string.august),
        context.getString(R.string.september),
        context.getString(R.string.october),
        context.getString(R.string.november),
        context.getString(R.string.december)
    )

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {

        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_week_mark_parent, parent, false)
        return ViewHolder(v, context)
    }

    override fun getItemCount(): Int {
        return mylist.size
    }

    override fun onBindViewHolder(
        holder: ViewHolder,
        position: Int
    ) {
        val parent = mylist[position]
        holder.onBind(parent)

        if (parent.lessons.isNotEmpty()) {
            holder.tvNot.visibility = View.GONE
            holder.rvhomework.visibility = View.VISIBLE

            val childLayoutManager =
                LinearLayoutManager(holder.rvhomework.context, RecyclerView.VERTICAL, false)
            holder.rvhomework.apply {
                layoutManager = childLayoutManager
                adapter = WeekChildMarkAdapter(parent.lessons)

                setRecycledViewPool(viewPool)
            }
        } else {
            holder.rvhomework.visibility = View.GONE
            holder.tvNot.visibility = View.VISIBLE
        }
    }

    inner class ViewHolder(override val containerView: View, private val context: Context) :
        RecyclerView.ViewHolder(containerView), LayoutContainer {
        val format = SimpleDateFormat("yyyy-MM-dd_HH:mm:ss")
        fun onBind(item: DailyWeekMarkModel) {
            itemView.tv_dayofweek_week.text = item.dayName

            if (item.lessons.isNotEmpty()) {
                val smdf = SimpleDateFormat("yyyy-MM-dd")
                    val date: Date = smdf.parse(item.lessons[0].date)
                    val day = DateFormat.format("dd", date) as String
                    when (day) {
                        "01" -> itemView.tv_day_week.text = "1"
                        "02" -> itemView.tv_day_week.text = "2"
                        "03" -> itemView.tv_day_week.text = "3"
                        "04" -> itemView.tv_day_week.text = "4"
                        "05" -> itemView.tv_day_week.text = "5"
                        "06" -> itemView.tv_day_week.text = "6"
                        "07" -> itemView.tv_day_week.text = "7"
                        "08" -> itemView.tv_day_week.text = "8"
                        "09" -> itemView.tv_day_week.text = "9"
                        else -> itemView.tv_day_week.text = day
                    }
                    val months = (DateFormat.format("MM", date) as String).toInt()
                    itemView.tv_month_week.text = monthList[months-1]
            } else {
                itemView.tv_day_week.text = (item.date.dayOfMonth).toString()
                itemView.tv_month_week.text = monthList[item.date.monthValue-1]
            }
        }

        val rvhomework: RecyclerView = itemView.rv_mark_week_parent
        val tvNot: TextView = itemView.tv_not_found_lesson
    }


    fun updateList(newlist: List<DailyWeekMarkModel>) {
        mylist.clear()
        mylist.addAll(newlist)
        this.notifyDataSetChanged()
    }
}