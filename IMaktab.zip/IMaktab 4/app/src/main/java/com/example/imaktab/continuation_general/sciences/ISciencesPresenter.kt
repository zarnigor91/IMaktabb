package com.example.imaktab.continuation_general.sciences

interface ISciencesPresenter{
    fun getAttendanceBySubjectAndMonth(subject:Int, month:Int)
   fun getSubjects(){}
}