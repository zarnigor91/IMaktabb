package com.example.imaktab.extension

object
Contstans {
    const val IMAGE_DIRECTORY = "/demonuts"
}