package com.example.imaktab.settings

data class SettingsRequest(
    val old_password:String,
    val new_password:String
)