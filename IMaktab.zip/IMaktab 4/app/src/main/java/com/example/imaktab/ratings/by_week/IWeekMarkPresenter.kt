package com.example.imaktab.ratings.by_week

interface IWeekMarkPresenter{
    fun getWeekMark(date:String)
    fun clearRequest()
}