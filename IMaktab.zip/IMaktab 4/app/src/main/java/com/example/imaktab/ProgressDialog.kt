package primo.team.uzbt.ui.global

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup


//class ProgressDialog(context: Context) : Dialog(context, R.style.ProgressDialogTheme) {
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.fr_progress)
//    }
//
//}