package com.example.imaktab.dashboard

data class PupilTotalResponce(
   val  my_total: Int
)