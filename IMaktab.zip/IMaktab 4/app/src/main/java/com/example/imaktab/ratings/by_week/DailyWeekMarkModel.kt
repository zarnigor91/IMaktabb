package com.example.imaktab.ratings.by_week

class DailyWeekMarkModel(
    val dayName:String,
    var date: org.threeten.bp.LocalDate,
    var lessons:List<MarkModel>
)