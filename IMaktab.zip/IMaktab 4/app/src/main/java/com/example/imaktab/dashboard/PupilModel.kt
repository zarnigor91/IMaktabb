package com.example.imaktab.dashboard

import com.google.gson.annotations.SerializedName

class PupilModel(
    val pupil: String,
    val pupil_id: String,
    val parent: Long,
    val klass: String
)
