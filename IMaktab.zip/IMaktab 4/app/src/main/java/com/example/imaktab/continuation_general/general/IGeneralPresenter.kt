package com.example.imaktab.continuation_general.general

interface IGeneralPresenter {
  fun  getContinuationWeek(data:String)
}