package com.example.imaktab.home_work

interface IHomeWorkPresenter{
    fun tomorrow()
    fun other()
    fun clearRequest()
    fun getPupilListByParentId()
}