package com.example.imaktab.data

class User (
    val login:String,
    val pass:String,
    val lan:String
)