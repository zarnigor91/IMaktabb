package com.example.imaktab

interface BaseView{
    fun showProgressDialog()
    fun hideProgressDialog()
}