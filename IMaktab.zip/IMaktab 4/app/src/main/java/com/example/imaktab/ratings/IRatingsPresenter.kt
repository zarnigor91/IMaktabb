package com.example.imaktab.ratings

interface IRatingsPresenter {
    fun clearRequest()
    fun getPupilListByParentId()
}